// JavaScript Document

document.write("<h1>Greeting</h1><p>Hello, how are you?</p>");