<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />

<meta name="keywords" content="Brothers Grimm, Hansel and Gretel, fairytale" />
<meta name="description" content="Read Hansel and Gretel accompanied by Arthur Rackham's illustrations" />

<title>Hansel and Gretel</title>

<link href="rules.css" rel="stylesheet" type="text/css" media="screen" />

</head>

<body>

<div id="main">

<div id="header">
</div>

<div id="bodyCopy">

<div id="nav">
<ul>
  <li>
      <a href="index.php">Page 1</a>
  </li>
  <li>
      <a href="page2.php">Page 2</a>
  </li>
  <li>
      <a href="page3.php">Page 3</a>
  </li>
  <li>
      <a href="page4.php">Page 4</a>
  </li>
  <li>
  <a href="http://en.wikipedia.org/wiki/Hansel_and_Gretel" target="_blank">About Hansel &amp; Gretel</a>
  </li>
  <li>
  <a href="http://en.wikipedia.org/wiki/Brothers_Grimm">About the Brothers Grimm</a>
  </li>
</ul>
</div>