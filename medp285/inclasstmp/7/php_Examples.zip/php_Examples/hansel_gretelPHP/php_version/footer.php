<div id="footer">

<ul>
  <li>
      <a href="index.php">Page 1</a>
  </li>
  <li>
      <a href="page2.php">Page 2</a>
  </li>
  <li>
      <a href="page3.php">Page 3</a>
  </li>
  <li>
      <a href="page4.php">Page 4</a>
  </li>
  <li>
  <a href="http://en.wikipedia.org/wiki/Hansel_and_Gretel" target="_blank">About Hansel &amp; Gretel</a>
  </li>
  <li>
  <a href="http://en.wikipedia.org/wiki/Brothers_Grimm">About the Brothers Grimm</a>
  </li>
</ul>

</div>

</div>
  
</body>
</html>